<?php

/**
 * The base view from which all Countries module views inherit.
 */
class countriesCountriesBaseView extends countriesBaseView
{

}

?>
<?php

/**
 * The base model from which all Countries module models inherit.
 */
class countriesCountriesBaseModel extends countriesBaseModel
{

}

?>
<?php

/**
 * The base action from which all Countries module actions inherit.
 */
class countriesCountriesBaseAction extends countriesBaseAction
{

}

?>